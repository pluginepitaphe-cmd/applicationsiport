#!/bin/bash
# Installation rapide SIPORTS WordPress Integration

set -e

echo "🚀 Installation SIPORTS WordPress Integration"
echo "============================================"

# Vérifier les prérequis
if [ "$EUID" -ne 0 ]; then
    echo "❌ Ce script doit être exécuté en tant que root"
    exit 1
fi

# Chemins par défaut
WORDPRESS_PATH="/var/www/html"
SIPORTS_PATH="/app"

# Vérifier WordPress
if [ ! -f "$WORDPRESS_PATH/wp-config.php" ]; then
    echo "❌ WordPress non trouvé dans $WORDPRESS_PATH"
    exit 1
fi

echo "✅ WordPress trouvé"

# Installer le plugin
echo "📦 Installation du plugin WordPress..."
cp -r wordpress-plugin/* "$WORDPRESS_PATH/wp-content/plugins/siports-integration/"
chown -R www-data:www-data "$WORDPRESS_PATH/wp-content/plugins/siports-integration/"

echo "✅ Plugin installé"

# Installer les extensions backend
echo "⚙️  Installation des extensions backend..."
cp backend-extensions/*.py "$SIPORTS_PATH/backend/"

# Installer les dépendances
echo "📚 Installation des dépendances..."
pip install -r backend-extensions/wordpress_requirements.txt

echo "✅ Extensions backend installées"

# Configuration
echo "🔧 Configuration..."
if [ -f "configuration/.env" ]; then
    cp configuration/.env "$SIPORTS_PATH/backend/"
    echo "✅ Configuration copiée"
else
    echo "⚠️  Fichier .env non trouvé, utilisez configuration/configure.sh"
fi

# Activer le plugin WordPress
echo "🔌 Activation du plugin..."
cd "$WORDPRESS_PATH"
wp plugin activate siports-integration --allow-root || echo "⚠️  Activation manuelle requise"

echo ""
echo "🎉 Installation terminée!"
echo ""
echo "📋 Prochaines étapes:"
echo "1. Configurez la base de données avec configuration/configure.sh"
echo "2. Redémarrez les services SIPORTS"
echo "3. Testez l'intégration dans WordPress admin"
echo ""
