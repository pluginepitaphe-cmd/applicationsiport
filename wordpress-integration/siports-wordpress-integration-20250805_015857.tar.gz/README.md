# 📦 SIPORTS WordPress Integration Package

Ce package contient tous les éléments nécessaires pour intégrer SIPORTS avec WordPress sur siportevent.com.

## 📁 Contenu du Package

```
siports-wordpress-package/
├── wordpress-plugin/          # Plugin WordPress complet
│   ├── siports-integration.php
│   └── build/                 # Assets JS/CSS
├── backend-extensions/        # Extensions FastAPI
│   ├── wordpress_config.py
│   ├── wordpress_extensions.py
│   └── wordpress_requirements.txt
├── configuration/             # Configuration
│   ├── env.template          # Template .env
│   └── configure.sh          # Script de configuration
├── scripts/                   # Scripts de déploiement
│   ├── deploy.sh            # Déploiement complet
│   └── install.sh           # Installation rapide
└── documentation/            # Documentation
    └── INSTALLATION_GUIDE.md # Guide détaillé

```

## 🚀 Installation Rapide

### Option 1: Installation automatique
```bash
sudo ./scripts/install.sh
```

### Option 2: Installation manuelle
1. Copiez `wordpress-plugin/` vers `/var/www/html/wp-content/plugins/siports-integration/`
2. Copiez `backend-extensions/*.py` vers `/app/backend/`
3. Installez les dépendances: `pip install -r backend-extensions/wordpress_requirements.txt`
4. Configurez avec `./configuration/configure.sh`
5. Activez le plugin dans WordPress admin

## 🔧 Configuration

### Base de données WordPress
Assurez-vous d'avoir:
- Host: localhost (ou votre host MySQL)
- Base: nom de votre base WordPress
- Utilisateur/mot de passe avec permissions

### Variables d'environnement
Copiez `configuration/env.template` vers `backend/.env` et remplissez:
```env
WP_DB_HOST=localhost
WP_DB_NAME=votre_base
WP_DB_USER=votre_user
WP_DB_PASSWORD=votre_password
```

## 📝 Utilisation

### Shortcodes WordPress

#### Dashboard Admin
```
[siports_app component="admin" height="800px"]
```

#### Packages Visiteur
```
[siports_app component="packages" height="600px"]
```

#### Système de Matching
```
[siports_app component="matching" height="700px"]
```

#### Application Complète
```
[siports_app component="main" height="900px"]
```

### Interface d'administration

Après activation, accédez à:
- **Configuration**: WordPress Admin → Réglages → SIPORTS Config
- **Synchronisation**: WordPress Admin → SIPORTS Sync

## 🔄 Synchronisation

L'intégration permet la synchronisation bidirectionnelle entre:
- Utilisateurs SIPORTS ↔ Utilisateurs WordPress  
- Packages SIPORTS ↔ Posts personnalisés WordPress
- Métadonnées et champs personnalisés

## 🛠️ Dépannage

### Plugin ne s'active pas
- Vérifiez les permissions fichiers (755/644)
- Consultez `/wp-content/debug.log`
- Vérifiez la syntaxe PHP

### Synchronisation échoue
- Vérifiez la configuration base de données
- Testez la connexion MySQL
- Consultez les logs backend

### Shortcodes ne fonctionnent pas
- Plugin activé ?
- Cache vidé ?
- Console navigateur pour erreurs JS

## 📞 Support

- Documentation complète: `documentation/INSTALLATION_GUIDE.md`
- Logs WordPress: `/wp-content/debug.log`
- Logs SIPORTS: `/app/logs/wordpress_integration.log`

## ✅ Checklist de Déploiement

- [ ] WordPress accessible et fonctionnel
- [ ] Plugin installé et activé
- [ ] Configuration base de données complétée
- [ ] Extensions backend installées
- [ ] Services SIPORTS redémarrés
- [ ] Tests shortcodes effectués
- [ ] Synchronisation testée

---

🎉 **Votre intégration SIPORTS WordPress est prête !**

Pour toute question ou problème, consultez la documentation détaillée ou les logs système.
