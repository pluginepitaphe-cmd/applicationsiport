#!/bin/bash
# Configuration automatique pour siportevent.com

echo "🔧 Configuration SIPORTS WordPress Integration"
echo "=============================================="

# Demander les informations de base de données
read -p "Host de la base de données [localhost]: " DB_HOST
DB_HOST=${DB_HOST:-localhost}

read -p "Nom de la base de données: " DB_NAME
read -p "Utilisateur de la base de données: " DB_USER
read -s -p "Mot de passe de la base de données: " DB_PASSWORD
echo

# Générer une clé JWT
JWT_KEY=$(openssl rand -hex 32)

# Créer le fichier .env
cat > .env << EOL
WP_DB_HOST=$DB_HOST
WP_DB_NAME=$DB_NAME
WP_DB_USER=$DB_USER
WP_DB_PASSWORD=$DB_PASSWORD
WP_TABLE_PREFIX=wp_
JWT_SECRET_KEY=$JWT_KEY
WORDPRESS_URL=https://siportevent.com
SIPORTS_API_URL=https://ec48b228-5fe8-445c-98da-33775eea8a9d.preview.emergentagent.com
LOG_LEVEL=INFO
EOL

echo "✅ Fichier .env créé avec succès!"
echo "🔐 Clé JWT générée automatiquement"
echo "📋 Vérifiez le fichier .env et ajustez si nécessaire"
